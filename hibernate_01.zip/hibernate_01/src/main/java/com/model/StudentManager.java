package com.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StudentManager
{
	public String addStudent(Student std) 
	{
		try 
		{
			Configuration config = new Configuration();
			SessionFactory sf = config.buildSessionFactory();
			Session ses =sf.openSession();
			Transaction ts = null;
			ts = ses.beginTransaction();
			ses.persist(std);
			ts.commit();
			
		} 
		catch (Exception e)
		{
			System.out.println(e);
		}
		
		return "saved";
		
	}
	  public List<Student> getAllStudents() {
	        try (Session session = new Configuration().configure().buildSessionFactory().openSession()) {
	            return session.createQuery("from Student", Student.class).list();
	        }
	    }

	    public void updateStudent(Student student) {
	        Transaction transaction = null;
	        try (Session session = new Configuration().configure().buildSessionFactory().openSession()) {
	            transaction = session.beginTransaction();
	            session.update(student);
	            transaction.commit();
	        }
	    }

	    public void deleteStudent(int id) {
	        Transaction transaction = null;
	        try (Session session = new Configuration().configure().buildSessionFactory().openSession()) {
	            transaction = session.beginTransaction();
	            Student student = session.get(Student.class, id);
	            if (student != null) {
	                session.delete(student);
	            }
	            transaction.commit();
	        }
	    }
}
